<?php

namespace App\Controllers;

use Sober\Controller\Controller;

class TemplateConceptualFramework extends Controller
{
    protected $acf = true;
}
