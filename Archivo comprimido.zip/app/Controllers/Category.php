<?php

namespace App\Controllers;

use Sober\Controller\Controller;

class Category extends Controller
{
    protected $acf = true;
}
